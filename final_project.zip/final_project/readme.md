pi-echo-debug should be called by the my-install function after the program has been installed; it should replace the role of pi-echo. Should be possible to just add this to the libunix folder.

The debugger code is adapted from labs/9-debug-hw from https://github.com/dddrrreee/cs140e-25win